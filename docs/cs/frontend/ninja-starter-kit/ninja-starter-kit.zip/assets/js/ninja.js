$(document).ready(function() {

    Ninja.init({
        debug:true
    });

});